﻿--------------------------MAPA BUS--------------------------

O Mapa Bus é um aplicativo para geolocalização de pontos de 
ônibus em Janaúba.

------------------------------------------------------------


O diretório "MapaBUS" contém os arquivos que compõem o aplicativo;

O diretório "Tools" possue outros arquivos que ajudaram na formação do conteúdo para a página:
são eles 'mapa.py' e 'lista1.csv'

------------------------------------------------------------

EQUIPE: 

Ádrian Marcello Mendes Dias

Camila Silva Alves

Jade Almeida Passos

Michelle de Oliveira Santos

-----------------------------------------------------------

PROJETOS FUTUROS:
CRIAR A APLICAÇÃO A PARTIR DO PHONEGAP BUILD


Devido alguns problemas, não conseguimos completar a criação da apk. Por isso, para o cumrpimento do prazo, postamos o site online.


Acesse o Site: http://mapabusjanauba-com.umbler.net/
